\begin{flushright}
\textit
Dedicado a mi familia y a todos\\
aquellos ...\\
\end{flushright}
