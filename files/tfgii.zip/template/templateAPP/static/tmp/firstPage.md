\begingroup
\thispagestyle{empty}
\begin{center}

\hspace{1mm}
\vspace{2cm}

\includegraphics[trim={13.5cm 0 0 0},clip,width=12cm]{static/images/logo_ccssttii_talavera.jpg}

\vspace{3cm}

\Large
UNIVERSIDAD DE CASTILLA-LA MANCHA

\vspace{1cm}

TRABAJO FIN DE GRADO

\vspace{1cm}

Departamento de  \Department

\vspace{0.25cm}

Tecnología Específica de  \Technology

\vspace{0.25cm}

\Title

\end{center}

\Large

\vspace{0.50cm}

Autor:  \Name

Tutor Académico:  \Tutor

Cotutor Académico:  \Cotutor

\flushright

\vspace*{\fill}

\Month , \Year

\endgroup

\cleardoublepage

