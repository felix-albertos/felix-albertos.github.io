<span id='HTML'>HTML</span>

: Lenguaje de marcas de hypertexto

<span id='HCI'>HCI</span>

: Human Computer Interaction

<span id='TFG'>TFG</span>

: Trabajo Final de Grado

