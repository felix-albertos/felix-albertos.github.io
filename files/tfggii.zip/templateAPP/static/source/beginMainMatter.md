
\mainmatter

\titleformat{\chapter}[display] % changed
{\normalfont\huge\bfseries}{\chaptertitlename\ \thechapter }{0pt}{\Huge}
\titlespacing*{\chapter}{0pt}{60pt}{30pt}

