
\frontmatter

  \titleformat{\chapter}[block]
    {\normalfont\normalsize\bfseries\justifyheading}{\thechapter.}{1em}{\Large}
  \titlespacing*{\chapter}{0pt}{45pt}{55pt}

