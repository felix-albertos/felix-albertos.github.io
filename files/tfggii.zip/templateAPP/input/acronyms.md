HTML: Lenguaje de marcas de hypertexto
HCI: Human Computer Interaction
TFG: Trabajo Final de Grado
